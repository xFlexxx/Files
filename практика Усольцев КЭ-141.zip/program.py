import transliterator
import lexicalBlock
import syntax

f = open('input.txt', 'r')
line = f.readline()
f.close()

f = open('output.txt', 'w')

transliteratorCheck = 1
lexicalCheck = 1
syntaxCheck = 1

transliteratorList, transliteratorCheck = transliterator.main(line)
listOfTokens, lexicalCheck = lexicalBlock.tokens(transliteratorList)
syntaxCheck = syntax.syntax(listOfTokens)

if transliteratorCheck == 0 and lexicalCheck == 0 and syntaxCheck == 0:
    f.write('ACCEPT')
else:
    f.write('REJECT')

f.close()