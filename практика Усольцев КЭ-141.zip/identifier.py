def identifier(line):
    bannedWords = ['and', 'end', 'nil', 'set', 'array', 'file', 'not', 'then', 'begin', 'for', 'of', 'to', 'case',
                   'function', 'or', 'type', 'const', 'goto', 'packed', 'until', 'if', 'procedure', 'var', 'do',
                   'in', 'mod', 'div', 'program', 'while', 'downto', 'label', 'record', 'with', 'else', 'repeat']
    identified = []
    for i in line:
        if i[0].lower() in bannedWords:
            identified.append((i[0], i[0].lower()))
        else:
            identified.append(i)
    return identified
