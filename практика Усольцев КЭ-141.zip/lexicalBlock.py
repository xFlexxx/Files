import identifier

def tokens(test):
    check = 0
    listOfTokens = [(' ', 'space')]

    def addNew(symbol, type):

        if listOfTokens[-1][1] == type:
            listOfTokens[-1] = (listOfTokens[-1][0] + symbol, listOfTokens[-1][1])
        else:
            listOfTokens.append((symbol, type))

    state = 'start'
    for i in test:
        if state == 'start':
            if i[1] == 'letter':
                state = 'state1'
                addNew(i[0], 'identifier')
            elif i[1] == 'space':
                addNew(i[0], 'space')
            else:
                check = 1
        elif state == 'state1':
            if i[1] == 'letter' or i[1] == 'digit':
                addNew(i[0], 'identifier')
            elif i[1] == 'space':
                state = 'state1_1'
                addNew(i[0], 'space')
            elif i[1] == 'colon':
                state = 'state2'
                addNew(i[0], 'colon')
            else:
                check = 1
        elif state == 'state1_1':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'colon':
                state = 'state2'
                addNew(i[0], 'colon')
            else:
                check = 1
        elif state == 'state2':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'equal':
                state = 'state3'
                addNew(i[0], 'equal')
            else:
                check = 1
        elif state == 'state3':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'letter':
                state = 'state4'
                addNew(i[0], 'array1')
            else:
                check = 1
        elif state == 'state4':
            if i[1] == 'space':
                state = 'state4_1'
                addNew(i[0], 'space')
            elif i[1] == 'letter' or i[1] == 'digit':
                addNew(i[0], 'array1')
            elif i[1] == 'squareBracketStart':
                state = 'state5'
                addNew(i[0], 'squareBracketStart')
            else:
                check = 1
        elif state == 'state4_1':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'squareBracketStart':
                state = 'state5'
                addNew(i[0], 'squareBracketStart')
            else:
                check = 1
        elif state == 'state5':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'mathSign':
                state = 'state6'
                addNew(i[0], 'arrIdentifier1')
            elif i[1] == 'letter':
                state = 'state7'
                addNew(i[0], 'arrIdentifier1')
            elif i[1] == 'digit':
                state = 'state6_1'
                addNew(i[0], 'arrIdentifier1')
            else:
                check = 1
        elif state == 'state6':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'digit':
                state = 'state6_1'
                addNew(i[0], 'arrIdentifier1')
            else:
                check = 1
        elif state == 'state6_1':
            if i[1] == 'space':
                state = 'state7_1'
                addNew(i[0], 'space')
            elif i[1] == 'digit':
                addNew(i[0], 'arrIdentifier1')
            elif i[1] == 'squareBracketEnd':
                state = 'state8'
                addNew(i[0], 'squareBracketEnd')
            else:
                check = 1
        elif state == 'state7':
            if i[1] == 'space':
                state = 'state7_1'
                addNew(i[0], 'space')
            elif i[1] == 'digit' or i[1] == 'letter':
                addNew(i[0], 'arrIdentifier1')
            elif i[1] == 'squareBracketEnd':
                state = 'state8'
                addNew(i[0], 'squareBracketEnd')
            else:
                check = 1
        elif state == 'state7_1':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'squareBracketEnd':
                state = 'state8'
                addNew(i[0], 'squareBracketEnd')
            else:
                check = 1
        elif state == 'state8':
            if i[1] == 'letter':
                state = 'state8_1'
                addNew(i[0], 'identifier')
            elif i[1] == 'mathSign' or i[1] == 'mult':
                state = 'state9'
                addNew(i[0], 'mathSign')
            elif i[1] == 'space':
                addNew(i[0], 'space')
            else:
                check = 1
        elif state == 'state8_1':
            if i[1] == 'letter':
                addNew(i[0], 'identifier')
            elif i[1] == 'space':
                state = 'state9'
                addNew(i[0], 'space')
            else:
                check = 1
        elif state == 'state9':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'letter':
                state = 'state10'
                addNew(i[0], 'func')
            else:
                check = 1
        elif state == 'state10':
            if i[1] == 'space':
                state = 'state10_1'
                addNew(i[0], 'space')
            elif i[1] == 'letter' or i[1] == 'digit':
                addNew(i[0], 'func')
            elif i[1] == 'parenthesisLeft':
                state = 'state11'
                addNew(i[0], 'parenthesisLeft')
            else:
                check = 1
        elif state == 'state10_1':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'parenthesisLeft':
                state = 'state11'
                addNew(i[0], 'parenthesisLeft')
            else:
                check = 1

        elif state == 'state11':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'letter':
                state = 'state12'
                addNew(i[0], 'array2')
            else:
                check = 1
        elif state == 'state12':
            if i[1] == 'space':
                state = 'state12_1'
                addNew(i[0], 'space')
            elif i[1] == 'letter' or i[1] == 'digit':
                addNew(i[0], 'array2')
            elif i[1] == 'squareBracketStart':
                state = 'state13'
                addNew(i[0], 'squareBracketStart')
            else:
                check = 1
        elif state == 'state12_1':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'squareBracketStart':
                state = 'state13'
                addNew(i[0], 'squareBracketStart')
            else:
                check = 1
        elif state == 'state13':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'mathSign':
                state = 'state14'
                addNew(i[0], 'arrIdentifier2')
            elif i[1] == 'letter':
                state = 'state15'
                addNew(i[0], 'arrIdentifier2')
            elif i[1] == 'digit':
                state = 'state14_1'
                addNew(i[0], 'arrIdentifier2')
            else:
                check = 1
        elif state == 'state14':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'digit':
                state = 'state14_1'
                addNew(i[0], 'arrIdentifier2')
            else:
                check = 1
        elif state == 'state14_1':
            if i[1] == 'space':
                state = 'state15_1'
                addNew(i[0], 'space')
            elif i[1] == 'digit':
                addNew(i[0], 'arrIdentifier2')
            elif i[1] == 'squareBracketEnd':
                state = 'state16'
                addNew(i[0], 'squareBracketEnd')
            else:
                check = 1
        elif state == 'state15':
            if i[1] == 'space':
                state = 'state15_1'
                addNew(i[0], 'space')
            elif i[1] == 'digit' or i[1] == 'letter':
                addNew(i[0], 'arrIdentifier2')
            elif i[1] == 'squareBracketEnd':
                state = 'state16'
                addNew(i[0], 'squareBracketEnd')
            else:
                check = 1
        elif state == 'state15_1':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'squareBracketEnd':
                state = 'state16'
                addNew(i[0], 'squareBracketEnd')
            else:
                check = 1
        elif state == 'state16':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'parenthesisRight':
                state = 'state17'
                addNew(i[0], 'parenthesisRight')
            else:
                check = 1
        elif state == 'state17':
            if i[1] == 'space':
                addNew(i[0], 'space')
            elif i[1] == 'semicolon':
                state = 'end'
                addNew(i[0], 'semicolon')
            else:
                check = 1
        elif state == 'end':
            if i[1]:
                check = 1
    if state != 'end':
        check = 1

    lexic = []
    for i in listOfTokens:
        if i[1] != 'space':
            lexic.append(i)

    lexic = identifier.identifier(lexic)
    return lexic, check

"""
test = [['a', 'letter'], ['[', 'squareBracketStart'], ['-', 'mathSign'], ['2', 'digit'], [']', 'squareBracketEnd'], [' ', 'space'], ['d', 'letter'], ['i', 'letter'], ['v', 'letter'], [' ', 'space'], ['f', 'letter'], ['(', 'parenthesisLeft'], ['a', 'letter'], ['[', 'squareBracketStart'], ['1', 'digit'], [']', 'square-BracketEnd'], [')', 'pa-renthesisRight'], [';', 'semicolon']]
test1 = [['a', 'letter'], [':', 'colon'], ['=', 'equal'], ['a', 'letter'], ['r', 'letter'], ['r', 'letter'], ['[', 'squareBracketStart'], ['2', 'digit'], ['6', 'digit'], [']', 'squareBracketEnd'], [' ', 'space'], ['m', 'letter'], ['o', 'letter'], ['d', 'letter'], [' ', 'space'], ['m', 'letter'], ['y', 'letter'], ['f', 'letter'], ['u', 'letter'], ['n', 'letter'], ['c', 'letter'], ['(', 'parenthesisLeft'], ['a', 'letter'], ['r', 'letter'], ['r', 'letter'], ['[', 'squareBracketStart'], ['8', 'digit'], [']', 'squareBracketEnd'], [')', 'parenthesisRight'], [';', 'semicolon']]
test2 = [['i', 'letter'], ['d', 'letter'], [':', 'colon'], ['=', 'equal'], ['a', 'letter'], ['r', 'letter'], ['r', 'letter'], ['[', 'squareBracketStart'], ['-', 'mathSign'], ['1', 'digit'], ['4', 'digit'], [']', 'squareBracketEnd'], [' ', 'space'], ['*', 'mult'], [' ', 'space'], ['m', 'letter'], ['y', 'letter'], ['f', 'letter'], ['u', 'letter'], ['n', 'letter'], ['c', 'letter'], ['(', 'parenthesisLeft'], ['a', 'letter'], ['r', 'letter'], ['r', 'letter'], ['[', 'squareBracketStart'], ['-', 'minus'], ['8', 'digit'], [']', 'squareBracketEnd'], [')', 'parenthesisRight'], [';', 'semicolon']]
example = [['b', 'letter'], [':', 'colon'], ['=', 'equal'], ['a', 'letter'], ['[', 'squareBracketStart'], ['i', 'letter'], [']', 'squareBracketEnd'], [' ', 'space'], ['+', 'mathSign'], [' ', 'space'], ['f', 'letter'], ['(', 'parenthesisLeft'], ['a', 'letter'], ['[', 'squareBracketStart'], ['i', 'letter'], [']', 'squareBracketEnd'], [')', 'parenthesisRight'], [';', 'semicolon']]

#Tests
print(tokens(test))
print(tokens(test1))
print(tokens(test2))
print(tokens(example))
"""
