def syntax(listOfTokens):

    state = 'start'
    check = 0
    for i in listOfTokens:
        if state == 'start':
            if i[1] == 'identifier':
                state = 'identifier'
            else:
                check = 1
        elif state == 'identifier':
            if i[1] == 'colon':
                state = 'colon'
            else:
                check = 1
        elif state == 'colon':
            if i[1] == 'equal':
                state = 'equal'
            else:
                check = 1
        elif state == 'equal':
            if i[1] == 'array1':
                state = 'array1'
            else:
                check = 1
        elif state == 'array1':
            if i[1] == 'squareBracketStart':
                state = 'squareBracketStart1'
            else:
                check = 1
        elif state == 'squareBracketStart1':
            if i[1] == 'arrIdentifier1':
                state = 'arrIdentifier1'
            else:
                check = 1
        elif state == 'arrIdentifier1':
            if i[1] == 'squareBracketEnd':
                state = 'squareBracketEnd1'
            else:
                check = 1
        elif state == 'squareBracketEnd1':
            if i[1] == 'mathSign' or i[1] == 'mult' or i[1] == 'mod' or i[1] == 'div':
                state = 'mathSign'
            else:
                check = 1
        elif state == 'mathSign':
            if i[1] == 'func':
                state = 'func'
            else:
                check = 1
        elif state == 'func':
            if i[1] == 'parenthesisLeft':
                state = 'parenthesisLeft'
            else:
                check = 1
        elif state == 'parenthesisLeft':
            if i[1] == 'array2':
                state = 'array2'
            else:
                check = 1
        elif state == 'array2':
            if i[1] == 'squareBracketStart':
                state = 'squareBracketStart2'
            else:
                check = 1
        elif state == 'squareBracketStart2':
            if i[1] == 'arrIdentifier2':
                state = 'arrIdentifier2'
            else:
                check = 1
        elif state == 'arrIdentifier2':
            if i[1] == 'squareBracketEnd':
                state = 'squareBracketEnd2'
            else:
                check = 1
        elif state == 'squareBracketEnd2':
            if i[1] == 'parenthesisRight':
                state = 'parenthesisRight'
            else:
                check = 1
        elif state == 'parenthesisRight':
            if i[1] == 'semicolon':
                state = 'end'
            else:
                check = 1
        elif state == 'end':
            if i[1]:
                check = 1
    if state != 'end':
        check = 1
    return check
"""
abc = [('b', 'identifier'), (':', 'colon'), ('=', 'equal'), ('a', 'array1'), ('[', 'squareBracketStart'), ('i', 'arrIdentifier1'), (']', 'squareBracketEnd'), ('+', 'mathSign'), ('f', 'func'), ('(', 'parenthesisLeft'), ('a', 'array2'), ('[', 'squareBracketStart'), ('i', 'arrIdentifier2'), (']', 'squareBracketEnd'), (')', 'parenthesisRight'), (';', 'semicolon')]
test2 = [('id', 'identifier'), ('=', 'equal'), ('arr', 'array1'), ('[', 'squareBracketStart'), ('-14', 'arrIdentifier1'), (']', 'squareBracketEnd'), ('*', 'mathSign'), ('myfunc', 'func'), ('(', 'parenthesisLeft'), ('arr', 'array2'), ('[', 'squareBracketStart'), ('-8', 'arrIdentifier2'), (']', 'squareBracketEnd'), (')', 'parenthesisRight'), (';', 'semicolon')]
print(syntax(abc))
print(syntax(test2))"""
