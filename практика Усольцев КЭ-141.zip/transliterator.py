def letters(symbol):
    alphabet = ('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'g', 'k', 'l', 'm',
         'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z')
    return symbol in alphabet

def numbers(symbol):
    d = ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
    return symbol in d

def mathSign(symbol):
    m = ('+', '-')
    return symbol in m

def main(line):
    line = line.lower()
    translitered = []
    flag = 0
    for i in range(len(line)):
        if letters(line[i]):
            translitered.append([line[i], 'letter'])
        elif numbers(line[i]):
            translitered.append([line[i], 'digit'])
        elif line[i] == ' ':
            translitered.append([line[i], 'space'])
        elif line[i] == '=':
            translitered.append([line[i], 'equal'])
        elif line[i] == '*':
            translitered.append([line[i], 'mult'])
        elif mathSign(line[i]):
            translitered.append([line[i], 'mathSign'])
        elif line[i] == ';':
            translitered.append([line[i], 'semicolon'])
        elif line[i] == ':':
            translitered.append([line[i], 'colon'])
        elif line[i] == '(':
            translitered.append([line[i], "parenthesisLeft"])
        elif line[i] == ')':
            translitered.append([line[i], "parenthesisRight"])
        elif line[i] == '[':
            translitered.append([line[i], 'squareBracketStart'])
        elif line[i] == ']':
            translitered.append([line[i], 'squareBracketEnd'])
        else:
            translitered.append([line[i], 'error'])
            flag = 1
    return translitered, flag
"""
print(main(input()))"""


